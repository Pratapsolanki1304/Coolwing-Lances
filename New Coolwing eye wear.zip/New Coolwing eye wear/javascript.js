
// gender

function showDivman() {
    document.getElementById("manSubmenu").style.display = "block";
    document.getElementById("offerone").style.display = "grid";
    document.getElementById("womanSubmenu").style.display = "none";
}
function hideDivman() {
    // document.getElementById("manSubmenu").style.display = "none";
}
function showDivwoman() {
    document.getElementById("womanSubmenu").style.display = "block";
    document.getElementById("manSubmenu").style.display = "none";
    document.getElementById("kidsSubmenu").style.display = "none";
}

function hideDivwoman() {
    document.getElementById("manSubmenu").style.display = "none";
    document.getElementById("kidsSubmenu").style.display = "none";

}
function showDivkids() {
    document.getElementById("kidsSubmenu").style.display = "block";
    document.getElementById("manSubmenu").style.display = "none";
    document.getElementById("womanSubmenu").style.display = "none";

}

function hideDivkids() {
    document.getElementById("womanSubmenu").style.display = "none";
    document.getElementById("manSubmenu").style.display = "none";
}

// man-category

function showDivofferone() {
    document.getElementById("offerone").style.display = "grid";
    document.getElementById("offerthree").style.display = "none";
    document.getElementById("offertwo").style.display = "none";
}
function hideDivofferone() {
    document.getElementById("offerthree").style.display = "none";
    document.getElementById("offertwo").style.display = "none";
}
function showDivoffertwo() {
    document.getElementById("offertwo").style.display = "grid";
    document.getElementById("offerone").style.display = "none";
    document.getElementById("offerthree").style.display = "none";
}
function hideDivoffertwo() {
    document.getElementById("offerone").style.display = "none";
    document.getElementById("offerthree").style.display = "none";
}
function showDivofferthree() {
    document.getElementById("offerthree").style.display = "grid";
    document.getElementById("offertwo").style.display = "none";
    document.getElementById("offerone").style.display = "none";
}
function hideDivofferthree() {
    document.getElementById("offertwo").style.display = "none";
}


// woman category

function showDivofferonew() {
    document.getElementById("offeronew").style.display = "grid";
    document.getElementById("offerthreew").style.display = "none";
    document.getElementById("offertwow").style.display = "none";
}
function hideDivofferonew() {
    document.getElementById("offerthreew").style.display = "none";
    document.getElementById("offertwow").style.display = "none";
}

function showDivoffertwow() {
    document.getElementById("offertwow").style.display = "grid";
    document.getElementById("offeronew").style.display = "none";
    document.getElementById("offerthreew").style.display = "none";
}
function hideDivoffertwow() {
    document.getElementById("offeronew").style.display = "none";
    document.getElementById("offerthreew").style.display = "none";
}
function showDivofferthreew() {
    document.getElementById("offerthreew").style.display = "grid";
    document.getElementById("offertwow").style.display = "none";
    document.getElementById("offeronew").style.display = "none";
}
function hideDivofferthreew() {
    document.getElementById("offertwow").style.display = "none";
}



// kisd category showDivofferthreekid

function showDivofferkid() {
    document.getElementById("offerkid").style.display = "grid";
    document.getElementById("offerthreew").style.display = "none";
    document.getElementById("offertwow").style.display = "none";
}
function hideDivofferkid() {

}
function nextdiv() {
    document.getElementById("nextdiv").style.display = "flex";
    document.getElementById("maindiv").style.display = "none";
}

function maindiv() {
    document.getElementById("maindiv").style.display = "flex";
    document.getElementById("nextdiv").style.display = "none";
}

function rightclick() {
    document.getElementById("nextdiv").style.display = "flex";
    document.getElementById("maindiv").style.display = "none";
}
function clicktomaindiv() {
    document.getElementById("maindiv").style.display = "flex";
    document.getElementById("nextdiv").style.display = "none";
}